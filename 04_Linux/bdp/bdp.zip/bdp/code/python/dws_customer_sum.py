# In[1]:
#!/usr/bin/env python
# coding: utf-8
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 26 16:44:47 2021
@author: admin1
"""
import configparser
import os
import sys
from numpy.matrixlib import defmatrix
import pymysql
import pandas as pd
import numpy as np
from collections import Counter
import re
from sqlalchemy import create_engine
import datetime
from dateutil.relativedelta import relativedelta
import getopt

pymysql.install_as_MySQLdb()
cf = configparser.ConfigParser()    
path = os.path.abspath(os.curdir)
confpath = path + "/conf/config4.ini"
cf.read(confpath)  # 读取配置文件，如果写文件的绝对路径，就可以不用os模块

user = cf.get("Mysql", "user")  # 获取user对应的值
password = cf.get("Mysql", "password")  # 获取password对应的值
db_host = cf.get("Mysql", "host")  # 获取host对应的值
database = cf.get("Mysql", "database")  # 获取dbname对应的值
date_quarter = '2021Q1'    #  获取季度（统计周期）
start_date = '20210101'   #  获取取数的开始年月日
stop_date = '20210401'   #  获取取数结束的年月日
table_name = 'dws_customer_sum'

# In[]

opts,args=getopt.getopt(sys.argv[1:],"d:t:q:s:e:",["database","table=","quarter=","startdate=","enddate="])
for opts,arg in opts:
  if opts=="-t" or opts=="--table":
    table_name = arg
  elif opts=="-q" or opts=="--quarter":
    date_quarter = arg
  elif opts=="-s" or opts=="--startdate":
    start_date = arg
  elif opts=="-e" or opts=="--enddate":
    stop_date = arg
  elif opts=="-d" or opts=="database":
        database = arg

# In[]

start_date_DF = datetime.datetime.strptime(start_date, "%Y%m%d")  #转换为yyyy-MM-dd HH:mm:ss 的时间格式
end_date_DF = datetime.datetime.strptime(stop_date, "%Y%m%d")     #转换为yyyy-MM-dd HH:mm:ss 的时间格式
pre_start_date = str(start_date_DF - relativedelta(months=+3))[0:10]   #截取成yyyy-MM-dd
pre_end_date =  str(end_date_DF - relativedelta(months=+3))[0:10]      #截取成yyyy-MM-dd


# -*- coding: utf-8 -*-
class MysqlClient:
    def __init__(self, db_host,database,user,password):
        """
        create connection to hive server
        """
        self.conn = pymysql.connect(host=db_host, user=user,password=password,database=database,charset="utf8")
    def query(self, sql):
        """
        query
        """
        cur = self.conn.cursor()
        cur.execute(sql)
        res = cur.fetchall()
        columnDes = cur.description #获取连接对象的描述信息
        columnNames = [columnDes[i][0] for i in range(len(columnDes))]
        data = pd.DataFrame([list(i) for i in res],columns=columnNames)
        cur.close()
        return data
    def close(self):
        self.conn.close()

def to_dws(result,table):
    engine = create_engine('mysql+mysqldb://'+user+':'+password+'@'+db_host+':'+'3306'+'/'+database)
    result.to_sql(name = table,con = engine,if_exists = 'append',index = False,index_label = False)

# In[18]:

#意向客户总量#
con = MysqlClient(db_host,database,user,password)
# dwb_customer_browse_log  客户浏览楼盘日志表（每日增量） 
#                                                      imei           客户号
#                                                      visit_date     浏览日期  
#                                                      newest_id      楼盘id
#                                                      pv             浏览次数  
ori=con.query("select newest_id,intention,orien,urgent,increase,retained from dwb_db.dwb_newest_customer_info where dr = 0 and period='"+date_quarter+"'")
# dws_newest_info  新房楼盘
#                                                      newest_id       楼盘id
#                                                      city_id         城市id  
#                                                      county_id       区县id  
admit=con.query("select newest_id from dws_db_prd.dws_newest_period_admit where dr = 0 and period='"+date_quarter+"'")
newest_id=con.query("select newest_id,city_id from dws_db_prd.dws_newest_info where newest_id is not null and city_id in ('110000','120000','130100','130200','130600','210100','220100','310000','320100','320200','320300','320400','320500','320600','321000','330100','330200','330300','330400','330500','330600','331100','340100','350100','350200','360100','360400','360700','370100','370200','370300','370600','370800','410100','420100','430100','440100','440300','440400','440500','440600','441200','441300','441900','442000','450100','460100','460200','500000','510100','520100','530100','610100','610300','610400') and county_id is not null and county_id != '' group by newest_id,city_id,county_id")
# 获取指定季度的楼盘id,和城市id，区县id
admit = pd.merge(admit,newest_id, how='inner', on=['newest_id'])


#In[]
# 获取楼盘的城市和区县，以及浏览基本情况
df = pd.merge(admit, ori, how='inner', on=['newest_id'])
# 修改列名
df.rename(columns={'newest_id':'newest'},inplace=True)
cus_sum = df[['city_id','newest','intention']]
# 修改列名
cus_sum.columns=['city_name','newest_name','cou_imei']
# 对城市名字分组，求取关注客户的平均值
cus_sum_city=cus_sum.groupby('city_name')['cou_imei'].mean().reset_index()
# 修改列名
cus_sum_city.columns=['city_name','city_avg']
# 均值对比：保留2位小数
cus_sum_city['city_avg']=round(cus_sum_city['city_avg'],2)
# 合并关注客户总量和关注客户均量比
cus_sum_res=pd.merge(cus_sum,cus_sum_city,how="left",on=['city_name'])
#  新增列tatio ，目标楼盘与城市平均比较  ==》 关注客户总量/关注客户的均量
cus_sum_res['ratio']=round(cus_sum_res['cou_imei']/cus_sum_res['city_avg']-1,4)
#  新增列，指定周期值
cus_sum_res['period']= date_quarter
#  截取指定列
cus_sum_res=cus_sum_res[['city_name','newest_name','period','cou_imei','city_avg','ratio']]
#  重命名列名
cus_sum_res.columns=['city_id','newest_id','period','cou_imei','city_avg','ratio']


# In[19]:

#  插入数据到dws_customer_sum表中
to_dws(cus_sum_res,table_name)#画像首页意向用户数总量


print('>> Done!') #完毕
