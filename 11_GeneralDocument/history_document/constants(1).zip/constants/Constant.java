package com.constants;

public interface Constant {
    String JDBC_DRIVER = "jdbc.driver";
    //公司mysql连接相关配置
    String JDBC_URL = "jdbc.url";
    String JDBC_PASSWORD = "jdbc.password";
    String JDBC_USERNAME = "jdbc.username";
    //本机mysql连接相关配置
    String JDBC_URL_LOCAL = "jdbc.url.local";
    String JDBC_PASSWORD_LOCAL = "jdbc.password.local";
    String JDBC_USERNAME_LOCAL = "jdbc.username.local";
}
