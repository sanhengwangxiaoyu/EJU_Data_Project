# mongodb表结构

## web_axios     

| Key               | Type   | Desc                                                |
| ----------------- | ------ | --------------------------------------------------- |
| app_id            | String | 所属系统ID                                          |
| create_time       | Date   | 用户访问时间                                        |
| url               | String | 访问的ajaxUrl                                       |
| speed_type        | Number | 访问速度类型 1：正常  2：慢                         |
| method            | String | 资源请求方式                                        |
| duration          | Number | AJAX响应时间 单位：ms                               |
| decoded_body_size | Number | 返回字段大小  单位：B                               |
| options           | String | ajax请求参数                                        |
| full_url          | String | 完整url                                             |
| call_url          | String | 调用页面的URL                                       |
| mark_page         | String | 所有资源页面统一标识 html img css js 用户系统信息等 |
| mark_user         | String | 统一某一时间段用户标识                              |
| app_mobile        | String | 用户手机                                            |



## web_environment

| Key             | Type   | Desc                                                |
| --------------- | ------ | --------------------------------------------------- |
| app_id          | String | 所属系统ID                                          |
| create_time     | Date   | 用户访问时间                                        |
| url             | String | 访问页面的url                                       |
| mark_page       | String | 所有资源页面统一标识 html img css js 用户系统信息等 |
| mark_user       | String | 统一某一时间段用户标识                              |
| mark_uv         | String | 统一uv标识                                          |
| browser         | String | 浏览器名称                                          |
| borwser_version | String | 浏览器版本                                          |
| system          | String | 操作系统                                            |
| system_version  | String | 系统版本                                            |
| ip              | String | 访问者IP                                            |
| county          | String | 国家                                                |
| province        | String | 省                                                  |
| city            | String | 市                                                  |
| app_mobile      | String | 用户手机                                            |



## web_errors

| Key          | Type   | Desc                                                |
| ------------ | ------ | --------------------------------------------------- |
| app_id       | String | 所属系统ID                                          |
| create_time  | Date   | 用户访问时间                                        |
| url          | String | 访问页面的url                                       |
| msg          | String | 错误信息                                            |
| category     | String | 错误类型                                            |
| resource_url | String | 错误资源URL                                         |
| target       | String | 资源类型                                            |
| type         | String | 错误类型                                            |
| status       | String | HTTP状态码                                          |
| text         | String | 资源错误提示                                        |
| col          | String | js错误列号                                          |
| line         | String | js错误行号                                          |
| querydata    | String | http请求参数                                        |
| method       | String | 资源请求方式                                        |
| fullurl      | String | 完整url                                             |
| mark_page    | String | 所有资源页面统一标识 html img css js 用户系统信息等 |
| mark_user    | String | 统一某一时间段用户标识                              |



## web_pages

| Key              | Type   | Desc                                                |
| ---------------- | ------ | --------------------------------------------------- |
| app_id           | String | 所属系统ID                                          |
| create_time      | Date   | 用户访问时间                                        |
| url              | String | url域名                                             |
| full_url         | String | 完整域名                                            |
| pre_url          | String | 用户访问的上一个页面，本页面来源                    |
| speed_type       | Number | 访问速度类型 1：正常  2：慢                         |
| is_first_in      | Number | 是否是某次会话的首次进入 2: 首次  1：非首次         |
| mark_page        | String | 所有资源页面统一标识 html img css js 用户系统信息等 |
| mark_user        | String | 统一某一时间段用户标识                              |
| load_time        | Number | 页面完全加载时间 单位：ms                           |
| dns_time         | Number | dns解析时间 单位：ms                                |
| tcp_time         | Number | TCP连接时间                                         |
| dom_time         | Number | DOM构建时间 单位：ms                                |
| resource_list    | Array  | 资源性能数据列表                                    |
| total_res_size   | Number | 页面资源大小                                        |
| white_time       | Number | 白屏时间 单位：ms                                   |
| redirect_time    | Number | 页面重定向时间                                      |
| unload_time      | Number | unload 时间                                         |
| request_time     | Number | request请求耗时                                     |
| analysisDom_time | Number | 解析dom耗时                                         |
| ready_time       | Number | 页面准备时间                                        |
| screenwidth      | Number | 屏幕宽度                                            |
| screenheight     | Number | 屏幕高度                                            |
| app_mobile       | String | 用户手机                                            |



## WebPvUvIp

| Key         | Type   | Desc                        |
| ----------- | ------ | --------------------------- |
| app_id      | String | 所属系统ID                  |
| pv          | Number | PV统计                      |
| uv          | Number | uv统计                      |
| ip          | Number | ip统计                      |
| ajax        | Number | ajax访问量统计              |
| bounce      | String | 跳出率                      |
| depth       | Number | 平均访问深度                |
| flow        | Number | 流量消费总额                |
| type        | Number | 1:每分钟数据  2：每小时数据 |
| create_time | Date   | default: Date.now           |



## WebReport

| Key              | Type   | Desc                                                    |
| ---------------- | ------ | ------------------------------------------------------- |
| app_id           | String | 所属系统ID                                              |
| create_time      | Date   | 用户访问时间                                            |
| user_agent       | String | 用户浏览器信息标识                                      |
| mark_page        | String | 所有资源页面统一标识 html img css js 用户系统信息等     |
| mark_userpre_url | String | 统一某一时间段用户标识                                  |
| mark_uv          | String | 统一uv标识                                              |
| url              | String | 访问url                                                 |
| pre_url          | String | 上一页面来源                                            |
| performance      | Mixed  | 用户浏览器性能数据                                      |
| error_list       | Mixed  | 错误信息列表                                            |
| resource_list    | Mixed  | 资源性能数据列表                                        |
| screenheight     | Number | 屏幕高度                                                |
| screenwidth      | Number | 屏幕宽度                                                |
| type             | Number | 1:网页性能上报  2：后续操作ajax上报 3：后续操作错误上报 |



## web_resources

| Key               | Type   | Desc                                                |
| ----------------- | ------ | --------------------------------------------------- |
| app_id            | String | 所属系统ID                                          |
| create_time       | Date   | 用户访问时间                                        |
| url               | String | 访问页面的url                                       |
| full_url          | String | 完整域名                                            |
| speed_type        | Number | 访问速度类型 1：正常  2：慢                         |
| resource_datas    | Mixed  | 页面所有加载资源json对象                            |
| name              | String | 资源名称                                            |
| method            | String | 资源请求方式                                        |
| type              | String | 资源类型                                            |
| duration          | Number | 资源请求耗时                                        |
| decoded_body_size | Number | 资源请求返回大小                                    |
| next_hop_protocol | String | 资源请求类型 default: 'http/1.1'                    |
| mark_user         | String | 统一某一时间段用户标识                              |
| mark_page         | String | 所有资源页面统一标识 html img css js 用户系统信息等 |



## WebStatis

| Key          | Type   | Desc                  |
| ------------ | ------ | --------------------- |
| app_id       | String | 所属系统ID            |
| create_time  | Date   | 用户访问时间          |
| top_pages    | Array  | top访问page列表       |
| top_jump_out | Array  | top访问跳出率页面列表 |
| top_browser  | Array  | top浏览器排行         |
| provinces    | Array  | 省份访问流量排行      |

