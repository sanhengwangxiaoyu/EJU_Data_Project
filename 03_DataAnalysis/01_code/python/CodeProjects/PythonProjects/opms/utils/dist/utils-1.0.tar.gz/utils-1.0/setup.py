from distutils.core import setup
setup(
    name='utils',
    version='1.0',
    description='第一个发布的模块，测试',
    author='Test',
    author_email='test@11.com',
    py_modules=['module1','mysqlclienttest']
)