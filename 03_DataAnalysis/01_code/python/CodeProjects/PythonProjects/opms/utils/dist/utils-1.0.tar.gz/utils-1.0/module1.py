print("practice define module")
def say_hi(user):
     print("%s say:hello,welcome to our place" % user)
say_hi("cathy")